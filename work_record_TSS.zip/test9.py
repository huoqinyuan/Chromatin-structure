from Bio import SeqIO,Seq,SeqRecord,SeqFeature
import numpy as np
import matplotlib.pyplot as plt
from single_seq_analyzer import single_seq_analyzer

length = len(Seq("CGCTAAAAGCTAGGATATATCCGGGTAGCTAG"))
a = Seq("CGCTAAAAGCTAGGATATATCCGGGTAGCTAG").count("A")/(length+0.00000000001)
t = Seq("CGCTAAAAGCTAGGATATATCCGGGTAGCTAG").count("T")/(length+0.00000000001)
c = Seq("CGCTAAAAGCTAGGATATATCCGGGTAGCTAG").count("C")/(length+0.00000000001)
g = Seq("CGCTAAAAGCTAGGATATATCCGGGTAGCTAG").count("G")/(length+0.00000000001)
print(a,t,c,g,sum(a,t,c,g))