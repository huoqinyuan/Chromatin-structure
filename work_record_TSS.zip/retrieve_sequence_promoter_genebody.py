﻿import sys
import numpy as np

fln=sys.argv[1]          #position
flnseq=sys.argv[2]       #fna
outname=sys.argv[3]      #output file name 

length=8000              #tss upstream length as promoter region 
bodylen=10000            #tss downstream length as gene body 

def seqreverse(seq):
    seq=seq.upper()
    seq=seq[::-1]
    new_seq=[]
    for i in range(len(seq)):
        if seq[i] == 'A':
            new_seq.append('T')
        elif seq[i] == 'T':
            new_seq.append('A')
        elif seq[i] == 'C':
            new_seq.append('G')
        elif seq[i] == 'G':
            new_seq.append('C')
        else:
            new_seq.append(seq[i])
    new_seq=''.join(new_seq)
    return new_seq

#-------input position and chain sign----------------------
chrname=[]
posx=[]
posy=[]
sign=[]

for line in open(fln):
    if line.split()[6] == '+' or line.split()[6] == '-':
        chrname.append(line.split()[0])
        posx.append(line.split()[3])
        posy.append(line.split()[4])
        if line.split()[6] == '+':
            sign.append(1)
        else:
            sign.append(-1)
print(len(chrname),'\t',len(posx),'\t',len(posy),'\t',len(sign))

#-----read in seq by chr/consider sign ---------
chrlist=list(set(chrname))
dataProBody=[]

for chr_tmp in chrlist:
    print(chr_tmp)
    genomeseq=[]
    flag=0
    for line in open(flnseq):
        if flag: 
            genomeseq.append(line.split()[0].upper())    
        if line.startswith('>'):
            if chr_tmp in line:
                flag=1
            else:
                flag=0
    genomeseq=''.join(genomeseq)
    
    for idd in range(len(chrname)): 
    #   print(idd)
        if chrname[idd] == chr_tmp:          
            posx_tmp=int(posx[idd])
            posy_tmp=int(posy[idd])
            if sign[idd] > 0:
                if posx_tmp > length  and  (posx_tmp+bodylen) < (len(genomeseq)-100) :
                    dataProBody.append(genomeseq[posx_tmp-length:posx_tmp+bodylen])    
                
            else:
                if (posy_tmp+length) < len(genomeseq)-100 and posy_tmp > bodylen :
                    tmp=seqreverse(genomeseq[posy_tmp-bodylen:posy_tmp+length])
                    dataProBody.append(tmp)                


#------------output sequence---------------------
fo=open('seq_probody_%s_pro%s.txt' % (outname,length) ,'w')
for idd in range(len(dataProBody)):
    fo.write('>ProBody %s \n' % idd )
    fo.write(dataProBody[idd])
    fo.write('\n')
fo.close()

