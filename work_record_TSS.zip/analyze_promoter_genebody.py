﻿import sys
import numpy as np
import matplotlib.pyplot as plt

flnPro=sys.argv[1]    #promoter to genebody sequence
figname=sys.argv[2]   #figure name

base=['AC','AG','AT','CA','CG','CT','GA','GC','GT','TA','TC','TG']
#--------------------input seq-----------------------------------------

dataPro=[]
seq_tmp=[]
for line in open(flnPro):
    if line.startswith('>'):
        if len(seq_tmp):
            seq_tmp=''.join(seq_tmp)
            dataPro.append(seq_tmp.upper())   
        seq_tmp=[]
    else:
        seq_tmp.append(line.strip())

length_seq=[len(i) for i in dataPro]
#print(length_seq)

#-------------------analyze by windows---------------------------------
lengthPro=8000
Bodylimit=8000


window=40
#num=lengthPro//window
num=(lengthPro+Bodylimit)//window
motiflen=2

rslt_win=[]
for seq in dataPro:
    dinu_density=[]    
    for k in ['AA','CC','GG','TT']:
        one_density=np.zeros(num)
        for idwin in range(num):
            seq_tmp=seq[idwin*window:(idwin+1)*window]    # count dinu
            Ncount=seq_tmp.count('N')                     #    
            count_tmp=0                                   #
            for i in range(len(seq_tmp)-motiflen+1):      #
                if seq_tmp[i:i+motiflen] == k:            #
                    count_tmp += 1                        # 
            one_density[idwin]=count_tmp/(float(window)-Ncount+0.00000000001)
        dinu_density.append(one_density)

    for k in base:
        one_density=np.zeros(num)
        for idwin in range(num):
            Ncount=seq[idwin*window:(idwin+1)*window].count('N')
            one_density[idwin]=seq[idwin*window:(idwin+1)*window].count(k)/(float(window)-Ncount+0.00000000001) 
        dinu_density.append(one_density)
    
    dinu_density=np.array(dinu_density)
    rslt_win.append(dinu_density)


dinu_avebyseq=np.zeros((16,num))         # cal average by seq 
for i in range(16):
    for j in range(num):
        tmp=[dinu[i,j] for dinu in rslt_win]
        tmp=np.array(tmp)
        dinu_avebyseq[i,j]=tmp.mean()

#------------------- plot figure --------------------
#['AA','CC','GG','TT','AC','AG','AT','CA','CG','CT','GA','GC','GT','TA','TC','TG']    

Xline=np.linspace(-(lengthPro//window),Bodylimit//window-1,num)

fig=plt.figure()
whichbase=[0,1,6,8]
name_base=['AA','CC','AT','CG']
for i in range(len(whichbase)):
    plt.subplot(2,2,i+1)
    plt.plot(Xline, dinu_avebyseq[whichbase[i],:])
    plt.title(name_base[i])

fig.tight_layout()
plt.savefig('./pic3/AA_CC_%s_%s' % (figname,window))
plt.clf()

fig=plt.figure()
whichbase=[4,5,7,10]
name_base=['AC','AG','CA','GA'] 
for i in range(len(whichbase)):
    plt.subplot(2,2,i+1)
    plt.plot(Xline, dinu_avebyseq[whichbase[i],:])
    plt.title(name_base[i])

fig.tight_layout()
plt.savefig('./pic3/AC_AG_%s_%s' % (figname,window))
plt.clf()

fig=plt.figure()
whichbase=[12,9,15,14]
name_base=['GT','CT','TG','TC'] 
for i in range(len(whichbase)):
    plt.subplot(2,2,i+1)
    plt.plot(Xline, dinu_avebyseq[whichbase[i],:])
    plt.title(name_base[i])

fig.tight_layout()
plt.savefig('./pic3/GT_CT_%s_%s' % (figname,window))
