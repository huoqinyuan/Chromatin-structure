﻿import sys
import numpy as np

fln=sys.argv[1]     #gff
filename=sys.argv[2]    #output filename

element='gene'
uplimit=800
space=3
#---------------------------------------

data=[]
count=0
for line in open(fln):
    if len(line.split())>2:
        if line.split()[2] == element:  
            count+=1
            if count%space == 0:
                data.append(line)
            
    if count > uplimit*space:
        break

fo=open('%s_NC_line.txt' % filename ,'w')
for i in range(len(data)):
    fo.write(data[i])
fo.close()
